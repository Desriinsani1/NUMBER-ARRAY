<?php
//desri insani
//2255201016
namespace Codecademy;
$php_array = array(
  "languange" => "php", 
  "Creator" => "Desri Insani",
  "year_created" => "2023",
  "filename_extencions" => [".php", ".phtml", ".php3", ".php4", ".php5", ".php7", ".phps", ".php-s", ".pht", ".phar"]);
// Write your code below: